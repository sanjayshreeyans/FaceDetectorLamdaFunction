import boto3
import datetime
import gspread
s3 = boto3.client('s3')
rekognition = boto3.client('rekognition')


def lambda_handler(event, context):
    # Get the object from the S3 event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    print(key, type(key))
    # Use Rekognition to detect faces in the uploaded image
    response = rekognition.search_faces_by_image(
        CollectionId='doc-example-collection-demo',
        Image={
            'S3Object': {
                'Bucket': bucket,
                'Name': key,
            }
        },
        FaceMatchThreshold=80,
        MaxFaces=10,
    )

    # If any faces are found, print their external IDs
    if len(response['FaceMatches']) > 0:
        for face_match in response['FaceMatches']:
            external_image_id = face_match['Face']['ExternalImageId']
            print(
                f"Face found with external ID {external_image_id} in image {key}")
            
            sa = gspread.service_account(filename='iep1-337004-678d886bff1c.json')

            sh = sa.open("Attendance Logs")

            wks = sh.worksheet("Sheet1")

            myfilename = key

            # extract the name from the filename
            my_ms = int(myfilename.split(".")[0])

            print(my_ms)
            my_datetime = datetime.datetime.fromtimestamp(my_ms / 1000)  # Apply fromtimestamp function
            print(my_datetime)
            my_datetime = my_datetime.strftime("%m/%d/%Y, %H:%M:%S")


                
            wks.append_row([external_image_id, my_datetime])

